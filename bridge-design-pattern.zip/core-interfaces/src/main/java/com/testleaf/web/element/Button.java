package com.testleaf.web.element;

public interface Button extends Element{

	void click();
	
}
