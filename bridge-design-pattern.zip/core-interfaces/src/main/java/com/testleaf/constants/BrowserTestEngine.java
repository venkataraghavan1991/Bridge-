package com.testleaf.constants;

public enum BrowserTestEngine {

	SELENIUM,
	PLAYWRIGHT
}
